#include <assert.h>
#include <stdio.h>
#include "01_plugins/mhw_ls_rebuild/c/world_core.c"
static void chain(unsigned rank,unsigned missed){
 WState s={.actor=1,.epoch=1,.move=W_BIG,.source=308+rank,.rank=rank,.rank_paid=1};
 WObservation o={.base={.actor=1,.epoch=1,.sample_sequence=1,.simulation_delta=1,.native_action=248,.motion=0x500+w_clip(308+rank)->slot,.animation_frame=70,.gauge=100},.state=16,.drawn=1,.alive=1,.grounded=1,.resources_ready=1,.rank=rank-(missed&&rank>0)};
 s.counter_success=!missed;
 WDecision prep=ground_enter(&s,&o,76,0);w_input_finish(&s,&o,prep);
 assert(prep.kind==W_ENTER&&prep.move==W_THRUST&&s.main_source==170);
 assert(prep.source==(rank==3?367:357)&&prep.start==0&&prep.speed==1);
 o.base.native_action=w_action(W_THRUST);o.base.motion=0x500+prep.slot;
 o.base.animation_frame=w_clip(prep.source)->length-1;o.base.motion_finished=1;++o.base.sample_sequence;
 WDecision main=w_step(&s,&o);w_input_finish(&s,&o,main);
 assert(main.kind==W_MOTION&&main.source==170&&main.start==(rank==3?66:50)&&main.speed==1);
 o.base.motion=0x500+main.slot;o.base.animation_frame=84;o.base.motion_finished=0;o.contact=1;++o.base.sample_sequence;
 WDecision rise=w_step(&s,&o);w_input_finish(&s,&o,rise);
 if(o.rank)assert(rise.kind==W_ENTER&&rise.move==W_RISE&&rise.start==0&&rise.speed==1);
 w_leave(&s);o.contact=0;o.base.animation_frame=0;
 WDecision fresh=enter(&s,&o,W_THRUST,0);assert(!fresh.motion_contract&&s.source==170&&s.main_source==0);
}
int main(void){
 for(unsigned rank=0;rank<=3;++rank)for(unsigned missed=0;missed<=1;++missed)chain(rank,missed);
 assert(w_clip(357)->length-w_clip(367)->length+66-50==22);
 puts("PASS: all ranks, hit/miss, red entry before tier loss, source prep/start, standard rise, no carried haste");
}
