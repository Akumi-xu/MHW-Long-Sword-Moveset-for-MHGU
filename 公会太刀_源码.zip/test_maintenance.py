from pathlib import Path
import subprocess
lab=Path(__file__).parent
source=(lab/'01_plugins/mhw_ls_rebuild/c/world_adapter.inc').read_text()
functions=source[source.index('static void world_maintenance('):source.index('static unsigned world_update(')]
stub=r'''
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
typedef uintptr_t u32; typedef uintptr_t uptr;
enum {STATE=0x2506,AREA=0x1054,HP=0x13d6};
static unsigned sample_sequence=1,world_last_sample,world_normal_gauge_tenths;
static float world_armor,world_regen,world_helm_regen,world_regen_fraction,world_regen_hud_frame,elapsed;
static unsigned ticks,clears,valid=1,resources=1;static uptr main_base;
static struct {u32 actor;unsigned epoch;} world;
static uint16_t u16(void*a,unsigned o){uint16_t v;memcpy(&v,(char*)a+o,2);return v;}
static unsigned word(void*a,unsigned o){unsigned v;memcpy(&v,(char*)a+o,4);return v;}
static float real(void*a,unsigned o){float v;memcpy(&v,(char*)a+o,4);return v;}
static unsigned byte(void*a,unsigned o){return ((unsigned char*)a)[o];}
static void put(void*a,unsigned o,unsigned v){memcpy((char*)a+o,&v,4);}
static void half(void*a,unsigned o,uint16_t v){memcpy((char*)a+o,&v,2);}
static unsigned local_guild(void*a){return valid&&a!=0;}
static unsigned world_ready(void*a){(void)a;return resources;}
static void world_detector_tick(void*a,float dt){(void)a;(void)dt;}
static void world_follow_tick(void*a,float dt){(void)a;elapsed+=dt;++ticks;}
static void world_follow_clear(void){++clears;}
static void world_audio_tick(void*a){(void)a;}
static void world_helm_line_tick(void*a){(void)a;}
'''
test=r'''
int main(void){
 unsigned char a[0x3400]={0};world.actor=(u32)a;world.epoch=5;a[AREA]=5;half(a,HP,100);float dt=1;memcpy(a+0x1c,&dt,4);
 for(unsigned s=1;s<=16;s=s==1?2:16){half(a,STATE,s);world_hurt_tick(a);assert(!ticks);if(s==16)break;}
 half(a,STATE,64);world_hurt_tick(a);assert(ticks==1&&fabsf(elapsed-1.f/60)<1e-6);
 world_hurt_tick(a);world_maintenance(a,1,1,1);assert(ticks==1);
 ++sample_sequence;world_maintenance(a,1,1,1);world_hurt_tick(a);assert(ticks==2);
 ++sample_sequence;half(a,HP,0);world_hurt_tick(a);assert(ticks==2&&clears==1);
 ++sample_sequence;half(a,HP,100);a[AREA]=6;world_hurt_tick(a);assert(ticks==2&&clears==2);
 ++sample_sequence;a[AREA]=5;resources=0;world_hurt_tick(a);assert(ticks==2&&clears==3);
 ++sample_sequence;resources=1;dt=0;memcpy(a+0x1c,&dt,4);world_hurt_tick(a);assert(ticks==2);
 ++sample_sequence;dt=40;memcpy(a+0x1c,&dt,4);world_hurt_tick(a);assert(ticks==2);
 ++sample_sequence;valid=0;world_hurt_tick(a);assert(ticks==2);
 puts("PASS: native hurt advances pending jobs; normal paths unchanged; sample dedupe; death/area/resources/invalid-delta guards");
}
'''
(lab/'maintenance_test.c').write_text('#define ML_WORLD_PRESENTATION 1\n'+stub+functions+test)
subprocess.run(['gcc',str(lab/'maintenance_test.c'),'-lm','-Wno-attributes','-o',str(lab/'maintenance_test.exe')],check=True)
subprocess.run([str(lab/'maintenance_test.exe')],check=True)
