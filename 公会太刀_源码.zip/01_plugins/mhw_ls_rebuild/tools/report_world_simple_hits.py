"""Check native one-shot visuals for every genuine delayed damage dispatch."""
import json,re
from pc_fixture import Fixture
from animation_port import PROJECT,sha

def main():
    f=Fixture();report={'status':'FAIL','run':str(f.run),
        'plugin_sha256':sha(f.run/'mods/MHW_WORLD_DEV/romfs/nativeNX/plugins/mhw_ls_rebuild.nro')}
    try:
        text=(f.run/'log.txt').read_text(errors='replace');events=[]
        for m in re.finditer(r'ML_REBUILD: (world_burst|world_simple_fx_emit) ([0-9A-F]+) ([0-9A-F]+) ([0-9A-F]+) ([0-9A-F]+)',text):
            events.append((m[1],*[int(v,16)for v in m.groups()[1:]]))
        pairs=[]
        for i,(event,actor,source,ordinal,shell)in enumerate(events):
            if event!='world_burst':continue
            assert i+1<len(events)
            visual=events[i+1]
            assert visual[0]=='world_simple_fx_emit' and visual[1]==actor and visual[2]==0x3f61+ordinal%3 and visual[4]==1,(events[i],visual)
            pairs.append({'damage_source':source,'ordinal':ordinal,'shell':shell,'visual_uid':visual[2]})
        assert len(pairs)>=7 and any(p['ordinal']==6 for p in pairs),pairs
        report.update(status='PASS_NATIVE_DELAYED_HIT_VISUALS',contacts=pairs,
            limits='One native visual per dispatched damage shell; this does not add another collider or damage request.')
        print(report['status'],len(pairs))
    except Exception as exc:report['error']=repr(exc);raise
    finally:
        (f.run/'simple_hit_fx.json').write_text(json.dumps(report,indent=2)+'\n')
        (PROJECT/'research/world_simple_hit_fx.json').write_text(json.dumps(report,indent=2)+'\n');f.close()

if __name__=='__main__':main()
