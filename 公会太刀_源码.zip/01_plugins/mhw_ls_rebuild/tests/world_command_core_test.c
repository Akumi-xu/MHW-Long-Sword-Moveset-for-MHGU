#include <assert.h>
#include <stdio.h>
#include "../c/world_core.h"
static WState s;
static WObservation o;
static WDecision tick(float frame,unsigned held)
{
    o.base.animation_frame=frame;o.base.held=held;++o.base.sample_sequence;
    WDecision d=w_step(&s,&o);w_input_finish(&s,&o,d);return d;
}
static void reset(unsigned idle)
{
    s=(WState){0};o=(WObservation){.base={.actor=1,.epoch=1,.sample_sequence=0,
        .native_action=idle?0:4,.motion=idle?0x501:0x569,.simulation_delta=1,.gauge=100},
        .state=idle?1:16,.drawn=1,.alive=1,.grounded=1,.rank=3,.resources_ready=1};
    tick(0,0);tick(0,0);tick(0,0);
}
static void bind(WDecision d)
{
    assert(d.kind==W_ENTER||d.kind==W_MOTION);
    o.state=16;o.base.native_action=w_action(d.move);o.base.motion=0x500+d.slot;
    o.base.animation_frame=d.motion_contract?d.start:0;o.base.motion_finished=0;
    int gauge=(int)o.base.gauge+d.gauge_delta;o.base.gauge=gauge<0?0:(unsigned)gauge;
}
static WDecision press(unsigned at,unsigned execute,unsigned keys)
{
    WDecision d={0};
    for(unsigned f=at;f<=execute;++f){
        d=tick((float)f,f<at+5?keys:0);
        if(f<execute)assert(d.kind==W_KEEP);
    }
    return d;
}
int main(void)
{
    /* GU owns the actual gauge debit. A normal opener must start at I. */
    WDecision d;
    for(unsigned gauge=0;gauge<=100;++gauge){
        reset(0);o.base.gauge=gauge;d=press(22,38,ML_R);
        assert(d.kind==W_NATIVE && d.native_action==(gauge>=15?16u:17u));
        assert(!s.move && !d.gauge_delta && !d.gauge_clear);
    }
    reset(0);d=press(1,42,ML_R);assert(d.kind==W_KEEP);
    reset(0);d=press(22,38,ML_A);assert(d.kind==W_KEEP&&!s.move);
    reset(0);d=press(22,38,ML_X);assert(d.kind==W_NATIVE&&d.native_action==25);
    o.base.native_action=25;o.base.motion=0x56b;tick(0,0);
    d=press(25,42,ML_A);assert(d.kind==W_NATIVE&&d.native_action==4);
    reset(0);o.base.native_action=22;o.base.motion=0x569;tick(0,0);
    d=press(28,38,ML_X);assert(d.kind==W_NATIVE&&d.native_action==25);
    for(unsigned previous=0;previous<3;++previous){
        reset(0);o.base.native_action=25;o.base.motion=0x56b;
        o.previous_weapon_action=(unsigned[]){4,22,23}[previous];tick(0,0);
        d=press(25,42,ML_R);
        if(previous==2)assert(d.kind==W_KEEP); /* GU owns Spirit II -> upper -> III. */
        else assert(d.kind==W_NATIVE&&d.native_action==16);
    }
    for(unsigned spirit=0;spirit<2;++spirit){
        reset(0);o.base.native_action=spirit?76:69;o.base.motion=spirit?0x568:0x565;
        tick(0,0);d=press(spirit?5:60,spirit?10:70,ML_R|ML_A);
        assert(d.kind==W_ENTER&&d.move==W_FORESIGHT);
        reset(0);o.base.native_action=spirit?76:69;o.base.motion=spirit?0x568:0x565;
        tick(0,0);d=press(spirit?5:60,spirit?10:70,ML_R|ML_B);
        assert(d.kind==W_ENTER&&d.move==W_SHEATHE);
        reset(0);o.base.native_action=spirit?76:69;o.base.motion=spirit?0x598:0x596;
        o.grounded=0;d=press(60,70,ML_R|ML_A);assert(d.kind==W_KEEP);
        d=press(80,90,ML_R|ML_B);assert(d.kind==W_KEEP);
    }
    reset(0);o.base.native_action=69;o.base.motion=0x565;tick(0,0);
    d=press(35,75,ML_R|ML_B);assert(d.kind==W_KEEP);
    /* A fresh airborne spirit chord may bridge the landing motion, but it
     * never starts a grounded sheath while the hunter is still airborne. */
    reset(0);o.base.native_action=74;o.base.motion=0x59b;o.grounded=0;
    for(unsigned f=0;f<6;++f)assert(tick(f,f==1?ML_R|ML_B:0).kind==W_KEEP);
    o.grounded=1;o.base.motion=0x59c;
    assert(tick(5,0).kind==W_KEEP);
    d=tick(10,0);assert(d.kind==W_ENTER&&d.move==W_SHEATHE);
    reset(0);o.base.native_action=76;o.base.motion=0x598;o.grounded=0;
    for(unsigned f=0;f<30;++f)assert(tick(f,f==1?ML_R|ML_B:0).kind==W_KEEP);
    o.grounded=1;o.base.motion=0x568;assert(tick(10,0).kind==W_KEEP);
    reset(0);o.base.native_action=76;o.base.motion=0x598;o.grounded=0;
    tick(1,ML_R|ML_B);o.base.epoch=2;tick(2,0);
    o.grounded=1;o.base.motion=0x568;assert(tick(10,0).kind==W_KEEP);
    reset(0);o.base.native_action=69;o.base.motion=0x565;tick(128,0);
    d=tick(135,ML_R|ML_B);assert(d.kind==W_ENTER&&d.move==W_SHEATHE);
    reset(0);o.base.native_action=76;o.base.motion=0x568;tick(60,0);
    d=press(61,71,ML_R|ML_B);assert(d.kind==W_KEEP);
    reset(0);o.base.native_action=16;o.base.motion=0x568;tick(0,0);
    d=press(36,56,ML_R|ML_B);assert(d.kind==W_ENTER&&d.move==W_SHEATHE);
    reset(0);o.base.native_action=41;o.base.motion=0x56b;tick(20,0);
    d=press(25,42,ML_A);assert(d.kind==W_NATIVE&&d.native_action==4);
    for(unsigned late=0;late<2;++late){
        reset(0);d=press(22,38,ML_R|ML_A);bind(d);tick(0,0);
        unsigned start=late?54:18,end=late?90:40;
        for(unsigned f=start;f<=end;++f){
            d=tick(f,f==start?ML_R|ML_B:0);
            if(f<end)assert(d.kind==W_KEEP);
        }
        assert(d.kind==W_ENTER&&d.move==W_SHEATHE);
    }
    for(unsigned i=0;i<3;++i){
        reset(0);o.base.native_action=(unsigned[]){7,25,41}[i];o.base.motion=0x56b;tick(20,0);
        d=press(25,42,ML_X);assert(d.kind==W_NATIVE&&d.native_action==5);
    }
    reset(0);d=tick(45,ML_R|ML_B);bind(d);d=press(65,80,ML_X);bind(d);
    d=press(30,50,ML_R|ML_A);assert(d.move==W_FORESIGHT);
    /* A Hunter Art can retain the previous weapon pose at entry. */
    for(unsigned art=51;art<=62;++art){
        reset(0);o.base.native_action=art;d=press(22,38,ML_R|ML_A);
        assert(d.kind==W_KEEP && !s.move);
    }
    reset(0);o.drawn=0;d=tick(0,0);assert(d.kind==W_KEEP);
    /* R+A is promoted before solo R. Both commands can be pending; the
     * original node4 edge order selects Foresight at the shared window. */
    reset(0);
    for(unsigned f=22;f<=38;++f){
        unsigned keys=f<27?ML_R:0;if(f>=23&&f<28)keys|=ML_A;
        d=tick((float)f,keys);if(f<38)assert(d.kind==W_KEEP);
    }
    assert(d.kind==W_ENTER&&d.move==W_FORESIGHT);
    for(unsigned i=0;i<4;++i){
        unsigned partner=i&1?ML_A:ML_X;
        unsigned first=i&2?partner:ML_R,second=i&2?ML_R:partner;
        reset(0);o.base.simulation_delta=1.000003f;
        for(unsigned f=22;f<=38;++f){
            unsigned keys=(f<28?first:0)|(f>=24&&f<28?second:0);
            d=tick((float)f,keys);if(f<38)assert(d.kind==W_KEEP);
        }
        assert(d.kind==W_ENTER&&d.move==(partner==ML_A?W_FORESIGHT:W_THRUST));
    }
    /* Dedicated post-small-Iai route, including both Spirit insertions.
     * Entry clocks are the source MBD contract, not GU native attack IDs. */
    reset(0);d=tick(45,ML_R|ML_B);assert(d.move==W_SHEATHE);bind(d);
    d=press(65,80,ML_X);assert(d.source==307);bind(d);
    d=press(30,50,ML_R);assert(d.source==363);bind(d);
    tick(0,0);d=tick(42,0);assert(d.kind==W_MOTION&&d.source==104&&d.start==42);bind(d);
    d=press(44,56,ML_A);
    assert(d.kind==W_NATIVE && d.native_action==22 && !s.move);
    assert(o.base.gauge==85);
    puts("PASS: Guild ownership, art pass-through, World chord, dedicated Iai opener and native return");
}
