"""Regression checks for the private EFX-to-EFL geometry and effect selection."""
import struct
import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from animation_port import ROOT, PROJECT, WORLD_MODEL, BODY_MAP, read_skeleton
from build_world_simple_fx import entries
from world_helm_iai_fx import EFL, attributes, emitter, single_parts
from world_thrust_foresight_fx import source_selection


def main():
    source_selection()
    bones=read_skeleton(WORLD_MODEL,True)
    inverse={world:gu for gu,world in BODY_MAP.items()}
    assert inverse[bones.functions[2]]==1
    assert inverse[bones.functions[1]]==0
    shells=json.loads((PROJECT/'research/world_shell_parameters.json').read_text())
    for name in ('finish_delay_hit_red','iaikijin_delay_hit_red'):
        fields=shells[name]['fields']
        assert fields['Projectile_Body_EPV_Index']['value']==2006
        assert fields['Obj_Hit_EPV_Index']['value']==2006
    arc=ROOT/'.cache/mhw_ls_combat/mods/MHW_WORLD_DEV/romfs/nativeNX/arc/forge/world_simple_fx.arc'
    catalog=entries(arc.read_bytes())
    poly=catalog['effect/world/iai_line',EFL][1]
    # Billboard template is unused by these ribbon-only regression cases.
    for clip,index in [('wp03_004',9),('wp03_004',21),('wp03_060',2)]:
        _,blocks=emitter(catalog,poly,poly,clip,index)
        unit=blocks[1]
        shape=attributes(clip,index)['RIBBON']
        a=struct.unpack_from('<3f',unit,544)
        b=struct.unpack_from('<3f',unit,560)
        length=sum((y-x)**2 for x,y in zip(a,b))**.5
        expected=shape['length']*shape['scale']
        if shape['ribbonMode']==0:
            speed=attributes(clip,index)['VELOCITY3D']['speed']
            expected=abs(speed)*(shape['subdivisionCount']-1)*shape['scale']
        assert abs(length-expected)<.001,(clip,index,length,expected)
    print('PASS: source EPV selections, rigid span and moving-trail span')


if __name__=='__main__':main()
