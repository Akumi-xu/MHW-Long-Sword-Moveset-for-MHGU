/* Locally generated appended records; stock rows stay byte-identical. */
#pragma once
typedef struct {unsigned source,hit,shape;} WHit;
static const WHit world_hits[]={
 {40u,85u,3u},
 {42u,86u,4u},
 {43u,87u,3u},
 {44u,88u,3u},
 {53u,89u,3u},
 {54u,90u,3u},
 {56u,91u,3u},
 {57u,92u,3u},
 {58u,93u,3u},
 {59u,94u,3u},
 {62u,95u,3u},
 {63u,96u,6u},
 {65u,97u,5u},
 {82u,98u,5u},
 {84u,99u,7u},
 {86u,100u,7u},
 {87u,101u,7u},
 {88u,102u,7u},
 {89u,103u,7u},
 {101u,104u,7u},
 {25961u,105u,8u},
 {26728u,106u,9u},
 {1001u,107u,10u},
 {1002u,108u,10u},
 {1003u,109u,10u},
 {1011u,110u,11u},
 {1012u,111u,11u},
 {1013u,112u,11u},
 {1021u,113u,10u},
 {1022u,114u,10u},
 {1023u,115u,10u},
};
#define WORLD_HIT_COUNT 116u
#define WORLD_SHAPE_COUNT 12u
