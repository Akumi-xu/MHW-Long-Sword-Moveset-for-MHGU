/* Generated from native FSM -> command -> permission-bit evidence. */
#pragma once
typedef struct {unsigned word,shift;} WInput;
static const WInput WI_X={0u,16u};
static const WInput WI_A={0u,30u};
static const WInput WI_ROLL={0u,8u};
static const WInput WI_FADE={1u,26u};
static const WInput WI_FADE_LEFT={2u,4u};
static const WInput WI_FADE_RIGHT={2u,6u};
static const WInput WI_THRUST={2u,8u};
static const WInput WI_FORESIGHT={2u,22u};
static const WInput WI_R={1u,12u};
static const WInput WI_SHEATHE={0u,14u};
