/* Generated from local source files by tools/import_evidence.py. */
static const MLMove ml_moves[] = {
    { ML_THRUST, 105u, 4u, 105u, 131.0f, 18.0f, 38.0f },
    { ML_FADE_BACK, 103u, 8u, 103u, 99.0f, 56.0f, 76.0f },
    { ML_FADE_LEFT, 127u, 29u, 128u, 91.0f, 50.0f, 72.0f },
    { ML_FADE_RIGHT, 128u, 28u, 129u, 89.0f, 50.0f, 72.0f },
    { ML_SPIRIT_STEP, 110u, 48u, 130u, 117.0f, 38.0f, 58.0f },
    { ML_SPIRIT_III, 108u, 26u, 108u, 201.0f, 75.0f, 95.0f },
    { ML_ROUND, 109u, 30u, 127u, 159.0f, 30.0f, 50.0f },
    { ML_UPPER, 107u, 7u, 107u, 137.0f, 22.0f, 42.0f },
};
