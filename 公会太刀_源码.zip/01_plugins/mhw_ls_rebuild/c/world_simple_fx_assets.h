#pragma once
#define WORLD_SIMPLE_FX_COUNT 108u
